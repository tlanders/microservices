package lci.biz.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestsampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestsampleApplication.class, args);
	}
}
